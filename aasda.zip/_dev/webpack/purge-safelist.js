
exports.module = {
  list: [

  ],
  patterns: [

  ]
}
